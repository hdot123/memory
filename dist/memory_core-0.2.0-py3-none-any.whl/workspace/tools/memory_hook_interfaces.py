#!/usr/bin/env python3
"""M2 Interface Definitions for memory-hook-gateway.

This module defines the core interfaces for the M2 refactoring:
- IF-1: HostDelegate
- IF-2: PolicyRegistry
- IF-3: RouteTargetPolicy / WriteTargetPolicy
- IF-4: ArtifactSink / ErrorSink
"""

from __future__ import annotations

import subprocess
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Protocol, TypedDict


# ---------------------------------------------------------------------------
# TypedDict for dict key contracts
# ---------------------------------------------------------------------------

class TruthBasis(TypedDict, total=False):
    """Typed contract for truth-basis packages returned by truth_basis_for_scope."""
    refs: list[str]
    errors: list[str]
    validation: str
    policy: str
    project_ref: str
    source_refs: list[str]
    authority_refs: list[str]
    evidence_refs: list[str]
    global_refs: list[str]
    conflict_status: list[str]


class RegistrationCommitGate(TypedDict, total=False):
    """Typed contract for registration commit gate probes."""
    phase: str
    enforced: bool
    gate_event: str
    triggered_on_current_event: bool
    enforcement_result: str
    status: str


# ---------------------------------------------------------------------------
# IF-1: HostDelegate
# ---------------------------------------------------------------------------

class HostDelegate(ABC):
    """Interface for delegating hook events to host runtime."""

    @abstractmethod
    def can_handle(self) -> bool:
        """Return True if this delegate can handle the current context."""
        pass

    @abstractmethod
    def execute(
        self,
        event: str,
        raw_payload: str,
        payload: dict[str, Any],
    ) -> subprocess.CompletedProcess[str]:
        """Execute the delegate for the given event.

        Returns:
            Process result including return code and captured output
        """
        pass

    @abstractmethod
    def noop_response(self) -> subprocess.CompletedProcess[str]:
        """Return a no-op response when formal runtime is unavailable.

        Each host adapter defines its own bypass output format.
        """
        pass


# ---------------------------------------------------------------------------
# IF-2: PolicyRegistry
# ---------------------------------------------------------------------------

class PolicyRegistry(ABC):
    """Interface for policy lookups and validation."""

    @abstractmethod
    def get_policy(self, key: str) -> str | None:
        """Get a policy value by key."""
        pass

    @abstractmethod
    def validate(self, context: dict[str, Any]) -> list[str]:
        """Validate the given context against registered policies.

        Returns:
            List of error messages (empty if valid)
        """
        pass

    @abstractmethod
    def get_policy_pack(self, scope: str) -> dict[str, Any]:
        """Get a policy pack for the given scope.

        Returns:
            Dict containing policy pack with schema_version, policies, conflict_strategy
        """
        pass

    @abstractmethod
    def resolve_conflict(self, policy_key: str, values: list[str], strategy: str) -> str:
        """Resolve conflicting policy values using the given strategy.

        Args:
            policy_key: The policy key in conflict
            values: List of conflicting values
            strategy: Conflict resolution strategy

        Returns:
            Resolved policy value

        Raises:
            ValueError: If conflict cannot be resolved
        """
        pass


    # Validation and scope lookup methods

    @abstractmethod
    def validate_project_map(self) -> list[str]:
        """Validate project-map contract files."""
        pass

    @abstractmethod
    def validate_unique_legal_system_contract(self) -> list[str]:
        """Validate unique legal system contract."""
        pass

    @abstractmethod
    def governance_frozen_tuple_errors(self) -> list[str]:
        """Return governance frozen tuple blocker errors."""
        pass

    @abstractmethod
    def event_contract_blocker_errors(self) -> list[str]:
        """Return event contract blocker errors."""
        pass

    @abstractmethod
    def git_registration_probe(self, event: str, payload: dict[str, Any]) -> RegistrationCommitGate:
        """Probe git registration for the given event and payload."""
        pass

    @abstractmethod
    def truth_basis_for_scope(self, scope: str) -> TruthBasis:
        """Return truth basis package for the given scope."""
        pass

    @abstractmethod
    def decision_refs_for_scope(self, scope: str) -> list[str]:
        """Return decision refs for the given scope."""
        pass

    @abstractmethod
    def lesson_refs_for_scope(self, scope: str) -> list[str]:
        """Return lesson refs for the given scope."""
        pass

    @abstractmethod
    def docs_refs_for_scope(self, scope: str) -> list[str]:
        """Return docs refs for the given scope."""
        pass




# ---------------------------------------------------------------------------
# Fine-grained Protocols (decomposed from PolicyRegistry)
# ---------------------------------------------------------------------------

class PolicyQueryProvider(Protocol):
    """策略查询 — 合法性来源、注册提交阶段等."""

    def legality_source_for_scope(self, scope: str) -> str: ...

    def registration_commit_phase_for_scope(self, scope: str) -> str: ...

    def get_policy(self, key: str) -> str | None: ...

    def get_policy_pack(self, scope: str) -> dict[str, Any]: ...

    def resolve_conflict(self, policy_key: str, values: list[str], strategy: str) -> str: ...


class GovernanceChecker(Protocol):
    """治理校验 — project-map、frozen tuple、event contract."""

    def validate_project_map(self) -> list[str]: ...

    def validate_unique_legal_system_contract(self) -> list[str]: ...

    def governance_frozen_tuple_errors(self) -> list[str]: ...

    def event_contract_blocker_errors(self) -> list[str]: ...

    def git_registration_probe(self, event: str, payload: dict[str, Any]) -> RegistrationCommitGate: ...


class TruthBasisProvider(Protocol):
    """事实基准 — truth-basis 查询、evidence refs."""

    def truth_basis_for_scope(self, scope: str) -> TruthBasis: ...

    def decision_refs_for_scope(self, scope: str) -> list[str]: ...

    def lesson_refs_for_scope(self, scope: str) -> list[str]: ...

    def docs_refs_for_scope(self, scope: str) -> list[str]: ...

# ---------------------------------------------------------------------------
# IF-3: RouteTargetPolicy / WriteTargetPolicy
# ---------------------------------------------------------------------------

class RouteTargetPolicy(ABC):
    """Interface for route target resolution."""

    @abstractmethod
    def resolve(self, kind: str) -> str:
        """Resolve a route kind to a target path.

        Raises:
            ValueError: If the route kind is not supported
        """
        pass


class WriteTargetPolicy(ABC):
    """Interface for write target resolution."""

    @abstractmethod
    def get_targets(self) -> dict[str, Any]:
        """Get all write targets.

        Returns:
            Dict mapping target keys to paths
        """
        pass


class GatewayBusinessPolicy(ABC):
    """Interface for host/business policy used by gateway orchestration."""

    @abstractmethod
    def determine_project_scope(self, cwd: Path) -> str:
        """Resolve project scope from cwd."""
        pass

    @abstractmethod
    def get_project_canonical(self) -> dict[str, Path]:
        """Return project canonical mapping."""
        pass

    @abstractmethod
    def get_project_runtime_root(self) -> dict[str, Path]:
        """Return project runtime root mapping."""
        pass

    def get_required_gateway_inputs(self) -> list[Path]:
        """Return required gateway inputs.

        Default to the legacy required_canonical bridge so older policy
        implementations remain compatible while gateway internals migrate.
        """
        return self.get_required_canonical()

    @abstractmethod
    def get_required_canonical(self) -> list[Path]:
        """Compatibility bridge for legacy required_canonical callers."""
        pass

    @abstractmethod
    def get_global_canonical(self) -> list[Path]:
        """Return global canonical files."""
        pass

    @abstractmethod
    def project_map_refs(self) -> list[str]:
        """Return project-map reference paths."""
        pass

    @abstractmethod
    def validate_project_map_files(self) -> list[str]:
        """Validate project-map contract files."""
        pass

    @abstractmethod
    def validate_unique_legal_system_contract(self) -> list[str]:
        """Validate unique legal system contract."""
        pass

    @abstractmethod
    def governance_frozen_tuple_blocker_errors(self) -> list[str]:
        """Return governance frozen tuple blocker errors."""
        pass

    @abstractmethod
    def event_contract_blocker_errors(self) -> list[str]:
        """Return event contract blocker errors."""
        pass

    @abstractmethod
    def decision_refs_for_scope(self, project_scope: str) -> list[str]:
        """Return decision refs for project scope."""
        pass

    @abstractmethod
    def lesson_refs_for_scope(self, project_scope: str) -> list[str]:
        """Return lesson refs for project scope."""
        pass

    @abstractmethod
    def docs_refs_for_scope(self, project_scope: str) -> list[str]:
        """Return docs refs for project scope."""
        pass

    @abstractmethod
    def truth_basis_for_scope(self, project_scope: str) -> TruthBasis:
        """Return truth basis package for project scope."""
        pass


# ---------------------------------------------------------------------------
# IF-4: ArtifactSink / ErrorSink
# ---------------------------------------------------------------------------

class ArtifactSink(ABC):
    """Interface for artifact output."""

    @abstractmethod
    def write(self, package: dict[str, Any]) -> dict[str, str]:
        """Write an artifact package.

        Returns:
            Dict with written artifact paths
        """
        pass

    @abstractmethod
    def ensure_dirs(self) -> None:
        """Ensure artifact directories exist."""
        pass


class ErrorSink(ABC):
    """Interface for error logging."""

    @abstractmethod
    def log(self, component: str, message: str, context: dict[str, Any]) -> None:
        """Log an error message."""
        pass


# ---------------------------------------------------------------------------
# IF-6: PathUtils
# ---------------------------------------------------------------------------

class PathUtils(ABC):
    """Path-related utility callbacks used by core assembly."""

    @abstractmethod
    def extract_excerpt(self, path: Path, max_lines: int = 12) -> list[str]:
        """Extract a brief excerpt from a file."""
        pass

    @abstractmethod
    def write_targets(self) -> dict[str, Any]:
        """Return the current write target map."""
        pass
